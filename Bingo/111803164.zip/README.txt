Requirements: python3

Installation:

	-open command prompt
	-run 'pip install pygame'
	-if doesn't work in unix, run 'sudo apt-get install python-pygame'

Run python game.py